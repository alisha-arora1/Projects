package com.capgemini.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.bean.Customerbean;
import com.capgemini.exception.CustomersException;
import com.capgemini.util.DBConnection;

public class CustomerDaoImpl implements ICustomerDAO {
	
	Logger logger=Logger.getRootLogger();
	
	public CustomerDaoImpl()
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	
	}
	
	@SuppressWarnings("resource")
	public String addCustomerDetails(Customerbean customerbean) throws CustomersException 
	{
		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		String customer_id=null;
		
		int queryResult=0;
		try
		{	
			
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);

			
			preparedStatement.setString(1, customerbean.getName());
			preparedStatement.setString(2, customerbean.getAge());
			preparedStatement.setString(3, customerbean.getPhoneNumber());
			preparedStatement.setString(4, customerbean.getProductInterested());
				
			
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(QueryMapper.CUSTOMERID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				customer_id=resultSet.getString(1);
						
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new CustomersException("Inserting Customer details failed ");

			}
			else
			{
				logger.info("Donor details added successfully:");
				return customer_id;
			}

		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			logger.error(sqlException.getMessage());
			throw new CustomersException("Tehnical problem occured refer log");
		}

		finally
		{
			try 
			{
				//resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new CustomersException("Error in closing db connection");

			}
		}
		
		
	}

	

}
